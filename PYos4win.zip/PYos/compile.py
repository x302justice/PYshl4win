
import py_compile
name = input("file name here: ")
fformat = input("format of file here")
if fformat == 'py' or 'pyw':
    print("compiling")
else:
    print("not proper format")
    input()
    exit
