import os
def clr(self):
    os.system('cls')
